# Gateway Sample Application

A desktop application that uses API available in SMS Gateway to send messages.

## Requirements

* [SMS Gateway](https://ebdsms.com) Account
* [Microsoft .NET Framework 4.6.2](https://www.microsoft.com/en-in/download/details.aspx?id=42642)